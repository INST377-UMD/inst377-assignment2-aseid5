function startVoice() {
  if (annyang) {
    const commands = {
      'go to home': () => window.location.href = 'index.html',
      'go to stocks': () => window.location.href = 'stocks.html',
      'go to dogs': () => window.location.href = 'dogs.html',
      'hello': () => alert('Hello there!'),
      'change the color to blue': () => document.body.style.backgroundColor = 'lightblue'
    };
    annyang.addCommands(commands);
    annyang.start();
  }
}

function stopVoice() {
  if (annyang) {
    annyang.abort();
  }
}

window.onload = function () {
  if (document.getElementById('quote')) {
    fetch('https://zenquotes.io/api/random')
      .then(res => res.json())
      .then(data => {
        document.getElementById('quote').innerText = data[0].q + ' — ' + data[0].a;
      })
      .catch(() => {
        document.getElementById('quote').innerText = "Failed to load quote.";
      });
  }
};